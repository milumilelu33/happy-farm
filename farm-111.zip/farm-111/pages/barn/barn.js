// 谷仓页面逻辑
const app = getApp();

Page({
  data: {
    animals: [],
    animalCount: 0,
    barnCapacity: 4
  },

  onLoad() {
    // 等待系统初始化
    if (!app.animalSystem || !app.saveSystem || !app.resourceSystem) {
      setTimeout(() => this.loadAnimalData(), 100);
      return;
    }
    this.loadAnimalData();
  },

  onShow() {
    if (app.animalSystem && app.saveSystem && app.resourceSystem) {
      this.loadAnimalData();
    }
  },

  /**
   * 预处理动物数据
   */
  processAnimalsData(animals) {
    const currentTime = Date.now();
    return animals.map(animal => {
      const result = { ...animal };
      const config = app.animalSystem.getAnimalConfig(animal.configId);

      result._animalIcon = '';
      result._animalName = '';
      result._statusText = '未知状态';
      result._growthProgress = 0;
      result._growthTimeRemaining = '';
      result._needFeed = false;
      result._feedCost = 0;

      if (config) {
        result._animalName = config.name || '';
        result._feedCost = config.feedCost || 0;

        // 状态文本
        switch (animal.status) {
          case 'baby':
            result._statusText = '幼崽 - 成长期';
            break;
          case 'growing':
            result._statusText = '成长中';
            break;
          case 'adult':
            result._statusText = '成年 - 待喂食';
            break;
          case 'producing':
            result._statusText = '生产中';
            break;
        }

        // 生长进度
        if (animal.boughtAt) {
          const growthTimeMs = config.growthTime * 1000;
          const elapsed = currentTime - animal.boughtAt;
          result._growthProgress = Math.min(100, (elapsed / growthTimeMs) * 100);
          const remainingSec = Math.max(0, Math.floor((growthTimeMs - elapsed) / 1000));
          if (remainingSec > 0) {
            const min = Math.floor(remainingSec / 60);
            const sec = remainingSec % 60;
            result._growthTimeRemaining = min > 0 ? `${min}分${sec}秒` : `${sec}秒`;
          } else {
            result._growthTimeRemaining = '';
          }
        }

        // 是否需要喂食
        if (animal.status !== 'baby' && animal.status !== 'growing' && !animal.productReady) {
          const lastFedAt = animal.lastProductAt || animal.fedAt;
          const timeSinceFeed = (currentTime - lastFedAt) / 1000;
          result._needFeed = timeSinceFeed > config.feedInterval;
        }
      }
      return result;
    });
  },

  /**
   * 加载动物数据
   */
  loadAnimalData() {
    const rawAnimals = app.animalSystem.getAllAnimals();
    this.setData({
      animals: this.processAnimalsData(rawAnimals),
      animalCount: rawAnimals.length,
      barnCapacity: app.animalSystem.getBarnCapacity()
    });
  },

  /**
   * 喂食动物
   */
  onFeedAnimal(e) {
    const instanceId = e.currentTarget.dataset.instanceId;
    const animal = app.animalSystem.getAnimal(instanceId);
    if (!animal) return;

    const config = app.animalSystem.getAnimalConfig(animal.configId);
    const feedCost = config.feedCost;

    // 检查金币
    const saveData = app.saveSystem.getCurrentSave();
    if (saveData.player.gold < feedCost) {
      this.showToast('金币不足！', 'error');
      return;
    }

    // 扣除金币并喂食
    app.resourceSystem.consume('gold', feedCost);
    app.animalSystem.feedAnimal(instanceId);
    app.saveSystem.save('auto');

    this.showToast(`喂养了 ${config.name}！`, 'success');
    this.loadAnimalData();
  },

  /**
   * 收获动物产品
   */
  onCollectProduct(e) {
    const instanceId = e.currentTarget.dataset.instanceId;
    const result = app.animalSystem.collectProduct(instanceId);

    if (result) {
      app.resourceSystem.add('animalProducts', result.count, result.productId);
      app.saveSystem.save('auto');

      this.showToast(`获得 ${result.count} 个 ${result.productName}！`, 'success');
      this.loadAnimalData();
    }
  },

  /**
   * 显示 Toast
   */
  showToast(message, type = '') {
    wx.showToast({
      title: message,
      icon: type === 'success' ? 'success' : 'none',
      duration: 2000
    });
  }
});
