// 设置页面逻辑
const app = getApp();

Page({
  data: {
    playerName: '农民',
    level: 1,
    soundEnabled: true,
    musicEnabled: true,
    notificationEnabled: true,
    saveInfo: {
      timestamp: '无存档',
      version: '1.0.0'
    }
  },

  onLoad() {
    // 等待系统初始化
    if (!app.saveSystem) {
      setTimeout(() => this.loadSettings(), 100);
      return;
    }
    this.loadSettings();
  },

  /**
   * 格式化时间戳
   */
  _formatTime(timestamp) {
    if (!timestamp) return '无存档';
    const date = new Date(timestamp);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  },

  onShow() {
    if (app.saveSystem) {
      this.loadSettings();
    }
  },

  /**
   * 加载设置
   */
  loadSettings() {
    const saveData = app.saveSystem.getCurrentSave();
    const saveInfo = app.saveSystem.getSaveInfo();

    this.setData({
      playerName: saveData.player.name,
      level: saveData.player.level,
      soundEnabled: saveData.settings.soundEnabled,
      musicEnabled: saveData.settings.musicEnabled,
      notificationEnabled: saveData.settings.notificationEnabled,
      saveInfo: {
        timestamp: saveInfo.exists ? this._formatTime(saveInfo.timestamp) : '无存档',
        version: saveData.version
      }
    });
  },

  /**
   * 音效开关
   */
  onSoundChange(e) {
    const enabled = e.detail.value;
    this.setData({
      soundEnabled: enabled
    });
    app.saveSystem.updateSave('settings.soundEnabled', enabled);
    app.saveSystem.save('auto');
  },

  /**
   * 音乐开关
   */
  onMusicChange(e) {
    const enabled = e.detail.value;
    this.setData({
      musicEnabled: enabled
    });
    app.saveSystem.updateSave('settings.musicEnabled', enabled);
    app.saveSystem.save('auto');
  },

  /**
   * 提醒开关
   */
  onNotificationChange(e) {
    const enabled = e.detail.value;
    this.setData({
      notificationEnabled: enabled
    });
    app.saveSystem.updateSave('settings.notificationEnabled', enabled);
    app.saveSystem.save('auto');
  },

  /**
   * 保存游戏
   */
  onSaveGame() {
    const success = app.saveSystem.save('manual');
    if (success) {
      wx.showToast({
        title: '保存成功',
        icon: 'success'
      });
    } else {
      wx.showToast({
        title: '保存失败',
        icon: 'none'
      });
    }
    this.loadSettings();
  },

  /**
   * 重置游戏
   */
  onResetGame() {
    wx.showModal({
      title: '确认重置',
      content: '确定要重置游戏吗？所有数据将被清空！',
      confirmColor: '#E53935',
      success: (res) => {
        if (res.confirm) {
          app.saveSystem.deleteSave();
          wx.showToast({
            title: '游戏已重置',
            icon: 'success'
          });
          // 重新加载
          setTimeout(() => {
            this.loadSettings();
          }, 1000);
        }
      }
    });
  }
});
