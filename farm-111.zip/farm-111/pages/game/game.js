// 游戏主页逻辑
const app = getApp();

Page({
  data: {
    // 玩家信息
    gold: 100,
    level: 1,
    experience: 0,
    expToNext: 100,
    expPercent: 0,

    // 土地数据（包含预处理后的显示属性）
    lands: [],

    // 动物数据（包含预处理后的显示属性）
    animals: [],
    animalCount: 0,
    barnCapacity: 4,

    // 弹窗状态
    showPlantModal: false,
    showHarvestModal: false,
    showUnlockModal: false,

    // 当前操作的索引
    currentLandIndex: -1,

    // 可选作物列表
    availableCrops: [],

    // 收获确认数据
    harvestModalData: {
      index: -1,
      cropId: '',
      name: '',
      yield: 0,
      experience: 0,
      icon: ''
    },

    // 解锁土地费用
    unlockCost: 100,

    // Toast 提示
    toast: {
      show: false,
      message: '',
      type: ''
    },

    // 状态栏图标占位
    goldIcon: '',
    levelIcon: '',
    lockIcon: '',
    plantIcon: '',
    productIcon: ''
  },

  timeManager: null,

  onLoad() {
    this.initGameData();

    // 监听游戏引擎更新
    if (app.gameEngine) {
      app.gameEngine.on('update', this.onGameUpdate.bind(this));
      app.gameEngine.on('cropReady', this.onCropReady.bind(this));
      app.gameEngine.on('offlineEarnings', this.onOfflineEarnings.bind(this));
    }
  },

  onShow() {
    // 确保系统已初始化后再刷新
    if (app.saveSystem && app.farmSystem && app.upgradeSystem && app.cropSystem && app.animalSystem && app.shopSystem && app.resourceSystem) {
      this.refreshGameData();
    }
  },

  onHide() {
    // 保存游戏
    if (app.saveSystem) {
      app.saveSystem.save('auto');
    }
  },

  /**
   * 预处理土地数据（添加显示属性，避免WXML调用函数）
   */
  processLandsData(lands) {
    const currentTime = Date.now();
    return lands.map(land => {
      const result = { ...land };
      result._cropIcon = '';
      result._growthProgress = 0;
      result._growthTimeRemaining = '';
      result._cropName = '';

      if (land.cropId) {
        const cropConfig = app.cropSystem.getCropConfig(land.cropId);
        if (cropConfig) {
          result._cropIcon = cropConfig.icon || '';
          result._cropName = cropConfig.name || '';
          if (land.plantedAt) {
            const elapsed = (currentTime - land.plantedAt) / 1000;
            result._growthProgress = Math.min(100, (elapsed / cropConfig.growthTime) * 100);
            const readyTime = land.plantedAt + cropConfig.growthTime * 1000;
            const remainingSec = Math.max(0, Math.floor((readyTime - currentTime) / 1000));
            if (remainingSec > 0) {
              const min = Math.floor(remainingSec / 60);
              const sec = remainingSec % 60;
              result._growthTimeRemaining = min > 0 ? `${min}分${sec}秒` : `${sec}秒`;
            } else {
              result._growthTimeRemaining = '';
            }
          }
        }
      }
      return result;
    });
  },

  /**
   * 预处理动物数据（添加显示属性）
   */
  processAnimalsData(animals) {
    return animals.map(animal => {
      const result = { ...animal };
      result._animalIcon = '';
      const config = app.animalSystem.getAnimalConfig(animal.configId);
      if (config) {
        result._animalIcon = config.icon || '';
      }
      return result;
    });
  },

  /**
   * 初始化游戏数据
   */
  initGameData() {
    // 防御性检查：确保所有系统已初始化
    if (!app.saveSystem || !app.farmSystem || !app.upgradeSystem || !app.cropSystem || !app.animalSystem || !app.shopSystem || !app.resourceSystem) {
      console.log('等待系统初始化...');
      setTimeout(() => this.initGameData(), 100);
      return;
    }

    const saveData = app.saveSystem.getCurrentSave();

    // 玩家信息
    this.setData({
      gold: saveData.player.gold,
      level: saveData.player.level,
      experience: saveData.player.experience
    });

    // 更新等级信息
    this.updateLevelInfo();

    // 土地数据
    const rawLands = app.farmSystem.getAllLands();
    this.setData({
      lands: this.processLandsData(rawLands)
    });

    // 动物数据
    this.updateAnimalData();

    // 解锁土地费用
    this.setData({
      unlockCost: app.farmSystem.calculateLandUnlockCost()
    });

    // 获取可用作物
    this.updateAvailableCrops();
  },

  /**
   * 刷新游戏数据
   */
  refreshGameData() {
    const saveData = app.saveSystem.getCurrentSave();
    const rawLands = app.farmSystem.getAllLands();

    this.setData({
      gold: saveData.player.gold,
      level: saveData.player.level,
      experience: saveData.player.experience,
      lands: this.processLandsData(rawLands)
    });

    this.updateLevelInfo();
    this.updateAnimalData();
    this.updateAvailableCrops();
  },

  /**
   * 更新等级信息
   */
  updateLevelInfo() {
    const levelConfig = app.upgradeSystem.getCurrentLevelConfig();
    const nextConfig = app.upgradeSystem.getNextLevelConfig();

    if (nextConfig) {
      const expNeeded = nextConfig.experienceRequired - levelConfig.experienceRequired;
      const expCurrent = this.data.experience - levelConfig.experienceRequired;
      const expPercent = Math.min(100, (expCurrent / expNeeded) * 100);

      this.setData({
        expToNext: expNeeded,
        expPercent: expPercent
      });
    } else {
      // 满级
      this.setData({
        expToNext: 'MAX',
        expPercent: 100
      });
    }
  },

  /**
   * 更新动物数据
   */
  updateAnimalData() {
    const rawAnimals = app.animalSystem.getAllAnimals();
    this.setData({
      animals: this.processAnimalsData(rawAnimals),
      animalCount: rawAnimals.length,
      barnCapacity: app.animalSystem.getBarnCapacity()
    });
  },

  /**
   * 更新可用作物
   */
  updateAvailableCrops() {
    const level = app.upgradeSystem.getPlayerLevel();
    const lands = this.data.lands;

    // 获取第一块空土地的等级（简化处理）
    const firstEmptyLand = lands.find(l => l.isUnlocked && l.status === 'empty');
    const landLevel = firstEmptyLand ? firstEmptyLand.level : 1;

    const crops = app.cropSystem.getAvailableCrops(level, landLevel);
    this.setData({
      availableCrops: crops
    });
  },

  /**
   * 游戏帧更新
   */
  onGameUpdate(data) {
    // 更新土地生长状态
    const rawLands = app.farmSystem.getAllLands();
    this.setData({
      lands: this.processLandsData(rawLands)
    });
  },

  /**
   * 作物成熟回调
   */
  onCropReady(data) {
    const { landIndex, cropId } = data;
    const land = this.data.lands[landIndex];

    if (land) {
      this.showToast(`${app.cropSystem.getCropName(cropId)} 成熟了！`, 'success');
    }
  },

  /**
   * 离线收益回调
   */
  onOfflineEarnings(earnings) {
    if (earnings.offlineSeconds < 60) return;

    const hours = Math.floor(earnings.offlineSeconds / 3600);
    const minutes = Math.floor((earnings.offlineSeconds % 3600) / 60);

    let message = `离线 ${hours > 0 ? hours + '小时' : ''}${minutes}分钟 `;

    if (Object.keys(earnings.crops).length > 0) {
      const totalCrops = Object.values(earnings.crops).reduce((a, b) => a + b, 0);
      message += `作物 x${totalCrops}`;
    }

    this.showToast(message, 'success');
  },

  /**
   * 点击土地
   */
  onLandTap(e) {
    const index = e.currentTarget.dataset.index;
    const land = this.data.lands[index];

    if (!land.isUnlocked) {
      // 解锁土地
      this.setData({
        currentLandIndex: index,
        showUnlockModal: true
      });
      return;
    }

    switch (land.status) {
      case 'empty':
        // 打开种植选择
        this.setData({
          currentLandIndex: index,
          showPlantModal: true
        });
        break;

      case 'growing':
      case 'planted':
        // 显示进度
        this.showToast('作物还在生长中...', '');
        break;

      case 'ready':
        // 收获
        this.showHarvestModal(index);
        break;
    }
  },

  /**
   * 显示收获弹窗
   */
  showHarvestModal(index) {
    const land = this.data.lands[index];
    const cropConfig = app.cropSystem.getCropConfig(land.cropId);
    const bonuses = app.upgradeSystem.getBonuses();
    const yield_count = app.cropSystem.calculateYield(land.cropId, bonuses.yield);

    this.setData({
      showHarvestModal: true,
      harvestModalData: {
        index: index,
        cropId: land.cropId,
        name: cropConfig.name,
        yield: yield_count,
        experience: cropConfig.experience,
        icon: cropConfig.icon
      }
    });
  },

  /**
   * 确认收获
   */
  onConfirmHarvest() {
    const { index, cropId, yield: yield_count, experience } = this.data.harvestModalData;

    // 执行收获
    const result = app.farmSystem.harvest(index, app.upgradeSystem.getBonuses().yield);

    if (result) {
      // 添加作物到背包
      app.resourceSystem.add('crops', result.yield, result.cropId);

      // 添加经验
      const leveledUp = app.upgradeSystem.addExperience(result.experience);

      // 更新UI
      this.refreshGameData();

      // 显示结果
      this.showToast(`收获 ${result.yield} 个 ${app.cropSystem.getCropName(result.cropId)}！+${experience}经验`, 'success');

      if (leveledUp) {
        setTimeout(() => {
          this.showToast(`升级了！现在是 Lv.${app.upgradeSystem.getPlayerLevel()}`, 'success');
        }, 500);
      }
    }

    this.setData({
      showHarvestModal: false,
      harvestModalData: {
        index: -1,
        cropId: '',
        name: '',
        yield: 0,
        experience: 0,
        icon: ''
      }
    });
  },

  /**
   * 关闭收获弹窗
   */
  onCloseHarvestModal() {
    this.setData({
      showHarvestModal: false
    });
  },

  /**
   * 选择作物
   */
  onSelectCrop(e) {
    const cropId = e.currentTarget.dataset.cropId;
    const cropConfig = app.cropSystem.getCropConfig(cropId);

    // 检查是否有种子
    const seedCount = app.resourceSystem.get('seeds', cropId);
    if (seedCount <= 0) {
      // 直接购买种子并种植
      const check = app.shopSystem.canPurchase(cropId + '_seeds', 1);
      if (!check.canBuy) {
        this.showToast(check.reason || '无法购买种子', 'error');
        return;
      }

      const result = app.shopSystem.purchase(cropId + '_seeds', 1);
      if (!result.success) {
        this.showToast(result.reason || '购买失败', 'error');
        return;
      }
    } else {
      // 消耗种子
      app.resourceSystem.consume('seeds', 1, cropId);
    }

    // 种植
    const success = app.farmSystem.plantCrop(this.data.currentLandIndex, cropId);
    if (success) {
      this.showToast(`种植了 ${cropConfig.name}！`, 'success');
      this.refreshGameData();
    }

    this.setData({
      showPlantModal: false
    });
  },

  /**
   * 关闭种植弹窗
   */
  onClosePlantModal() {
    this.setData({
      showPlantModal: false
    });
  },

  /**
   * 确认解锁土地
   */
  onConfirmUnlock() {
    const index = this.data.currentLandIndex;
    const cost = this.data.unlockCost;

    // 检查金币
    if (this.data.gold < cost) {
      this.showToast('金币不足！', 'error');
      return;
    }

    // 扣除金币
    app.resourceSystem.consume('gold', cost);

    // 解锁土地
    const success = app.farmSystem.unlockLand(index, cost);
    if (success) {
      this.showToast('土地解锁成功！', 'success');
      this.refreshGameData();

      // 更新解锁费用
      this.setData({
        unlockCost: app.farmSystem.calculateLandUnlockCost()
      });
    }

    this.setData({
      showUnlockModal: false
    });
  },

  /**
   * 关闭解锁弹窗
   */
  onCloseUnlockModal() {
    this.setData({
      showUnlockModal: false
    });
  },

  /**
   * 点击动物
   */
  onAnimalTap(e) {
    const instanceId = e.currentTarget.dataset.instanceId;
    const animal = app.animalSystem.getAnimal(instanceId);

    if (!animal) return;

    if (animal.productReady) {
      // 收集产品
      const result = app.animalSystem.collectProduct(instanceId);
      if (result) {
        app.resourceSystem.add('animalProducts', result.count, result.productId);
        this.showToast(`获得 ${result.count} 个 ${result.productName}！`, 'success');
        this.refreshGameData();
      }
    } else {
      // 检查是否需要喂食
      const config = app.animalSystem.getAnimalConfig(animal.configId);
      const currentTime = Date.now();
      const lastFedAt = animal.lastProductAt || animal.fedAt;
      const timeSinceFeed = (currentTime - lastFedAt) / 1000;

      if (timeSinceFeed > config.feedInterval) {
        // 需要喂食
        const feedCost = config.feedCost;
        if (this.data.gold >= feedCost) {
          app.resourceSystem.consume('gold', feedCost);
          app.animalSystem.feedAnimal(instanceId);
          this.showToast(`喂养了 ${config.name}，花了 ${feedCost} 金币`, 'success');
          this.refreshGameData();
        } else {
          this.showToast('金币不足，无法喂养！', 'error');
        }
      } else {
        this.showToast(`${config.name} 正在生产中...`, '');
      }
    }
  },

  /**
   * 显示 Toast 提示
   */
  showToast(message, type = '') {
    this.setData({
      toast: {
        show: true,
        message: message,
        type: type
      }
    });

    setTimeout(() => {
      this.setData({
        'toast.show': false
      });
    }, 2000);
  },

  /**
   * 获取作物图标
   */
  getCropIcon(cropId) {
    const config = app.cropSystem.getCropConfig(cropId);
    return config ? config.icon : '';
  },

  /**
   * 获取动物图标
   */
  getAnimalIcon(configId) {
    const config = app.animalSystem.getAnimalConfig(configId);
    return config ? config.icon : '';
  },

  /**
   * 获取生长进度
   */
  getGrowthProgress(land) {
    if (!land.cropId || !land.plantedAt) return 0;

    const cropConfig = app.cropSystem.getCropConfig(land.cropId);
    if (!cropConfig) return 0;

    const currentTime = Date.now();
    const elapsed = (currentTime - land.plantedAt) / 1000;
    const progress = Math.min(100, (elapsed / cropConfig.growthTime) * 100);

    return progress;
  },

  /**
   * 获取剩余生长时间
   */
  getGrowthTimeRemaining(land) {
    if (!land.cropId || !land.plantedAt) return '';

    const cropConfig = app.cropSystem.getCropConfig(land.cropId);
    if (!cropConfig) return '';

    const currentTime = Date.now();
    const readyTime = land.plantedAt + cropConfig.growthTime * 1000;
    const remainingSec = Math.max(0, Math.floor((readyTime - currentTime) / 1000));

    if (remainingSec > 0) {
      const min = Math.floor(remainingSec / 60);
      const sec = remainingSec % 60;
      return min > 0 ? `${min}分${sec}秒` : `${sec}秒`;
    }
    return '';
  },

  /**
   * 阻止事件冒泡
   */
  preventBubble() {}
});
