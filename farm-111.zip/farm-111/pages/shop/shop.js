// 商店页面逻辑
const app = getApp();

Page({
  data: {
    gold: 100,
    currentCategory: 'seeds',
    categories: [
      { id: 'seeds', name: '种子' },
      { id: 'animals', name: '动物' },
      { id: 'buildings', name: '建筑' },
      { id: 'tools', name: '工具' }
    ],
    shopItems: []
  },

  onLoad() {
    // 等待系统初始化
    if (!app.shopSystem || !app.saveSystem || !app.resourceSystem) {
      setTimeout(() => this.loadShopData(), 100);
      return;
    }
    this.loadShopData();
  },

  onShow() {
    if (app.shopSystem && app.saveSystem && app.resourceSystem) {
      this.refreshGold();
      this.loadShopItems();
    }
  },

  /**
   * 预处理商品数据
   */
  processShopItems(items) {
    return items.map(item => {
      const result = { ...item };
      result._currentPrice = app.shopSystem.getCurrentPrice(item.id);
      result._todayPurchased = app.shopSystem.getTodayPurchased(item.id);
      const check = app.shopSystem.canPurchase(item.id, 1);
      result._canBuy = check.canBuy;
      result._cannotBuyReason = check.reason || '';
      return result;
    });
  },

  /**
   * 加载商店数据
   */
  loadShopData() {
    this.refreshGold();
    this.loadShopItems();
  },

  /**
   * 刷新金币显示
   */
  refreshGold() {
    const saveData = app.saveSystem.getCurrentSave();
    this.setData({
      gold: saveData.player.gold
    });
  },

  /**
   * 加载商店商品
   */
  loadShopItems() {
    const items = app.shopSystem.getItemsByCategory(this.data.currentCategory);
    this.setData({
      shopItems: this.processShopItems(items)
    });
  },

  /**
   * 切换分类
   */
  onTabChange(e) {
    const category = e.currentTarget.dataset.category;
    this.setData({
      currentCategory: category
    });
    this.loadShopItems();
  },

  /**
   * 购买商品
   */
  onBuyItem(e) {
    const itemId = e.currentTarget.dataset.itemId;
    const result = app.shopSystem.purchase(itemId, 1);

    if (result.success) {
      this.showToast(result.message || '购买成功！', 'success');
      this.refreshGold();
      this.loadShopItems();
    } else {
      this.showToast(result.reason || '购买失败', 'error');
    }
  },

  /**
   * 显示 Toast
   */
  showToast(message, type = '') {
    wx.showToast({
      title: message,
      icon: type === 'success' ? 'success' : 'none',
      duration: 2000
    });
  }
});
