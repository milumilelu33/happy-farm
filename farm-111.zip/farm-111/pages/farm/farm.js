// 农场详情页面逻辑
const app = getApp();

Page({
  data: {
    stats: {
      totalLands: 16,
      unlockedLands: 4,
      plantedLands: 0,
      readyLands: 0
    },
    inventory: [],
    animalProducts: []
  },

  onLoad() {
    // 等待系统初始化
    if (!app.farmSystem || !app.saveSystem || !app.resourceSystem || !app.cropSystem) {
      setTimeout(() => this.loadFarmData(), 100);
      return;
    }
    this.loadFarmData();
  },

  onShow() {
    if (app.farmSystem && app.saveSystem && app.resourceSystem && app.cropSystem) {
      this.loadFarmData();
    }
  },

  /**
   * 加载农场数据
   */
  loadFarmData() {
    const lands = app.farmSystem.getAllLands();
    const resources = app.resourceSystem.getAllResources();

    // 计算统计数据
    const stats = {
      totalLands: lands.length,
      unlockedLands: lands.filter(l => l.isUnlocked).length,
      plantedLands: lands.filter(l => l.status === 'growing' || l.status === 'planted').length,
      readyLands: lands.filter(l => l.status === 'ready').length
    };

    // 作物库存
    const inventory = [];
    const crops = resources.crops || {};
    for (const [cropId, count] of Object.entries(crops)) {
      if (count > 0) {
        const config = app.cropSystem.getCropConfig(cropId);
        if (config) {
          inventory.push({
            id: cropId,
            name: config.name,
            count: count
          });
        }
      }
    }

    // 动物产品
    const animalProducts = [];
    const products = resources.animalProducts || {};
    for (const [productId, count] of Object.entries(products)) {
      if (count > 0) {
        animalProducts.push({
          id: productId,
          name: productId,
          count: count
        });
      }
    }

    this.setData({
      stats: stats,
      inventory: inventory,
      animalProducts: animalProducts
    });
  },

  /**
   * 一键出售全部
   */
  onSellAll() {
    let totalGold = 0;
    let soldCount = 0;

    // 出售作物
    const crops = this.data.inventory;
    crops.forEach(item => {
      const config = app.cropSystem.getCropConfig(item.id);
      if (config) {
        const gold = config.sellPrice * item.count;
        totalGold += gold;
        soldCount += item.count;
        // 清空库存
        app.resourceSystem.set('crops', 0, item.id);
      }
    });

    // 出售动物产品（简化：统一价格）
    const products = this.data.animalProducts;
    products.forEach(item => {
      totalGold += 20 * item.count; // 假设每个产品20金币
      soldCount += item.count;
      app.resourceSystem.set('animalProducts', 0, item.id);
    });

    if (totalGold > 0) {
      app.resourceSystem.add('gold', totalGold);
      app.saveSystem.save('auto');

      wx.showToast({
        title: `出售 ${soldCount} 件，获得 ${totalGold} 金币！`,
        icon: 'success'
      });

      this.loadFarmData();
    } else {
      wx.showToast({
        title: '没有可出售的物品',
        icon: 'none'
      });
    }
  }
});
