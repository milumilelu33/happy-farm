module.exports = {
  "shopItems": [
    {
      "id": "land_expand",
      "category": "buildings",
      "name": "开垦新土地",
      "description": "解锁一块新的土地",
      "basePrice": 100,
      "priceGrowth": 1.5,
      "maxPurchases": 12,
      "icon": "/assets/icons/land.png",
      "unlockLevel": 1
    },
    {
      "id": "barn_expand",
      "category": "buildings",
      "name": "扩建谷仓",
      "description": "增加一个动物栏位",
      "basePrice": 200,
      "priceGrowth": 1.8,
      "maxPurchases": 6,
      "icon": "/assets/icons/barn_expand.png",
      "unlockLevel": 1
    },
    {
      "id": "wheat_seeds",
      "category": "seeds",
      "name": "小麦种子",
      "description": "种植小麦，60秒成熟",
      "price": 10,
      "icon": "/assets/crops/wheat.png",
      "unlockLevel": 1
    },
    {
      "id": "corn_seeds",
      "category": "seeds",
      "name": "玉米种子",
      "description": "种植玉米，120秒成熟",
      "price": 20,
      "icon": "/assets/crops/corn.png",
      "unlockLevel": 2
    },
    {
      "id": "tomato_seeds",
      "category": "seeds",
      "name": "番茄种子",
      "description": "种植番茄，180秒成熟",
      "price": 35,
      "icon": "/assets/crops/tomato.png",
      "unlockLevel": 3
    },
    {
      "id": "strawberry_seeds",
      "category": "seeds",
      "name": "草莓种子",
      "description": "种植草莓，240秒成熟",
      "price": 50,
      "icon": "/assets/crops/strawberry.png",
      "unlockLevel": 4
    },
    {
      "id": "chicken",
      "category": "animals",
      "name": "购买母鸡",
      "description": "购买一只母鸡，可产蛋",
      "price": 50,
      "icon": "/assets/animals/chicken.png",
      "unlockLevel": 1
    },
    {
      "id": "cow",
      "category": "animals",
      "name": "购买奶牛",
      "description": "购买一头奶牛，可产奶",
      "price": 150,
      "icon": "/assets/animals/cow.png",
      "unlockLevel": 3
    },
    {
      "id": "pig",
      "category": "animals",
      "name": "购买猪",
      "description": "购买一头猪，可产松露",
      "price": 300,
      "icon": "/assets/animals/pig.png",
      "unlockLevel": 5
    },
    {
      "id": "feed",
      "category": "tools",
      "name": "动物饲料",
      "description": "喂养动物，维持产出",
      "price": 5,
      "icon": "/assets/icons/feed.png",
      "unlockLevel": 1
    }
  ]
};
