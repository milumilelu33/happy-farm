module.exports = {
  "crops": [
    {
      "id": "wheat",
      "name": "小麦",
      "seedCost": 10,
      "growthTime": 60,
      "harvestYield": 1,
      "sellPrice": 25,
      "requiredLandLevel": 1,
      "experience": 5,
      "color": "#F4D03F",
      "icon": "/assets/crops/wheat.png"
    },
    {
      "id": "corn",
      "name": "玉米",
      "seedCost": 20,
      "growthTime": 120,
      "harvestYield": 1,
      "sellPrice": 50,
      "requiredLandLevel": 2,
      "experience": 10,
      "color": "#F5B041",
      "icon": "/assets/crops/corn.png"
    },
    {
      "id": "tomato",
      "name": "番茄",
      "seedCost": 35,
      "growthTime": 180,
      "harvestYield": 2,
      "sellPrice": 45,
      "requiredLandLevel": 3,
      "experience": 15,
      "color": "#E74C3C",
      "icon": "/assets/crops/tomato.png"
    },
    {
      "id": "strawberry",
      "name": "草莓",
      "seedCost": 50,
      "growthTime": 240,
      "harvestYield": 1,
      "sellPrice": 80,
      "requiredLandLevel": 4,
      "experience": 20,
      "color": "#FF6B81",
      "icon": "/assets/crops/strawberry.png"
    }
  ]
};
