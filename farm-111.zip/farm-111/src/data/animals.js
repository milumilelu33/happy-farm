module.exports = {
  "animals": [
    {
      "id": "chicken",
      "name": "母鸡",
      "feedCost": 5,
      "feedInterval": 300,
      "growthTime": 600,
      "productId": "egg",
      "productName": "鸡蛋",
      "productInterval": 600,
      "productYield": 1,
      "sellPrice": 100,
      "requiredBarnLevel": 1,
      "experience": 15,
      "color": "#FDFEFE",
      "icon": "/assets/animals/chicken.png"
    },
    {
      "id": "cow",
      "name": "奶牛",
      "feedCost": 15,
      "feedInterval": 600,
      "growthTime": 1200,
      "productId": "milk",
      "productName": "牛奶",
      "productInterval": 900,
      "productYield": 1,
      "sellPrice": 300,
      "requiredBarnLevel": 2,
      "experience": 30,
      "color": "#FDFEFE",
      "icon": "/assets/animals/cow.png"
    },
    {
      "id": "pig",
      "name": "猪",
      "feedCost": 20,
      "feedInterval": 480,
      "growthTime": 1800,
      "productId": "truffle",
      "productName": "松露",
      "productInterval": 1200,
      "productYield": 1,
      "sellPrice": 500,
      "requiredBarnLevel": 3,
      "experience": 50,
      "color": "#FDFEFE",
      "icon": "/assets/animals/pig.png"
    }
  ]
};
