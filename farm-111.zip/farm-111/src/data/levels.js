module.exports = {
  "levels": [
    {
      "level": 1,
      "experienceRequired": 0,
      "unlockLandCount": 4,
      "unlockBarnCount": 2,
      "unlockCropIds": ["wheat"],
      "unlockAnimalIds": ["chicken"],
      "growthSpeedBonus": 0,
      "yieldBonus": 0
    },
    {
      "level": 2,
      "experienceRequired": 100,
      "unlockLandCount": 6,
      "unlockBarnCount": 3,
      "unlockCropIds": ["corn"],
      "unlockAnimalIds": [],
      "growthSpeedBonus": 5,
      "yieldBonus": 0
    },
    {
      "level": 3,
      "experienceRequired": 300,
      "unlockLandCount": 8,
      "unlockBarnCount": 4,
      "unlockCropIds": ["tomato"],
      "unlockAnimalIds": ["cow"],
      "growthSpeedBonus": 10,
      "yieldBonus": 5
    },
    {
      "level": 4,
      "experienceRequired": 600,
      "unlockLandCount": 10,
      "unlockBarnCount": 5,
      "unlockCropIds": ["strawberry"],
      "unlockAnimalIds": [],
      "growthSpeedBonus": 15,
      "yieldBonus": 10
    },
    {
      "level": 5,
      "experienceRequired": 1000,
      "unlockLandCount": 12,
      "unlockBarnCount": 6,
      "unlockCropIds": [],
      "unlockAnimalIds": ["pig"],
      "growthSpeedBonus": 20,
      "yieldBonus": 15
    },
    {
      "level": 6,
      "experienceRequired": 1500,
      "unlockLandCount": 14,
      "unlockBarnCount": 7,
      "unlockCropIds": [],
      "unlockAnimalIds": [],
      "growthSpeedBonus": 25,
      "yieldBonus": 20
    },
    {
      "level": 7,
      "experienceRequired": 2200,
      "unlockLandCount": 16,
      "unlockBarnCount": 8,
      "unlockCropIds": [],
      "unlockAnimalIds": [],
      "growthSpeedBonus": 30,
      "yieldBonus": 25
    }
  ],
  "maxLevel": 7
};
