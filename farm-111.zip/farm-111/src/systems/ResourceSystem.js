/**
 * 资源管理系统
 * 负责管理金币、种子、作物、饲料、动物产品等资源
 */
const { EventManager, GameEvents } = require('../core/EventManager');

class ResourceSystem {
  constructor() {
    this.eventManager = new EventManager();

    // 资源存储
    this.resources = {
      gold: 100, // 初始金币
      seeds: {},      // 种子库存 { cropId: count }
      crops: {},      // 作物库存 { cropId: count }
      feeds: {},      // 饲料库存
      animalProducts: {}, // 动物产品 { productId: count }
      tools: {}       // 工具
    };
  }

  /**
   * 获取资源数量
   * @param {string} type - 资源类型
   * @param {string} id - 资源ID（可选）
   */
  get(type, id = null) {
    if (id) {
      if (type === 'seeds') return this.resources.seeds[id] || 0;
      if (type === 'crops') return this.resources.crops[id] || 0;
      if (type === 'feeds') return this.resources.feeds[id] || 0;
      if (type === 'animalProducts') return this.resources.animalProducts[id] || 0;
      if (type === 'tools') return this.resources.tools[id] || 0;
    }
    return this.resources[type] || 0;
  }

  /**
   * 添加资源
   * @param {string} type - 资源类型
   * @param {number} amount - 数量
   * @param {string} id - 资源ID（可选）
   */
  add(type, amount, id = null) {
    if (id) {
      if (!this.resources[type]) this.resources[type] = {};
      this.resources[type][id] = (this.resources[type][id] || 0) + amount;
    } else {
      this.resources[type] = (this.resources[type] || 0) + amount;
    }

    this.eventManager.emit(GameEvents.RESOURCE_CHANGED, { type, id, amount, action: 'add' });
    if (type === 'gold') {
      this.eventManager.emit(GameEvents.GOLD_CHANGED, { gold: this.resources.gold });
    }
  }

  /**
   * 消耗资源
   * @param {string} type - 资源类型
   * @param {number} amount - 数量
   * @param {string} id - 资源ID（可选）
   * @returns {boolean} 是否成功
   */
  consume(type, amount, id = null) {
    const current = this.get(type, id);
    if (current < amount) {
      return false;
    }

    if (id) {
      this.resources[type][id] -= amount;
      if (this.resources[type][id] <= 0) {
        delete this.resources[type][id];
      }
    } else {
      this.resources[type] -= amount;
    }

    this.eventManager.emit(GameEvents.RESOURCE_CHANGED, { type, id, amount, action: 'consume' });
    if (type === 'gold') {
      this.eventManager.emit(GameEvents.GOLD_CHANGED, { gold: this.resources.gold });
    }
    return true;
  }

  /**
   * 检查是否有足够的资源
   * @param {string} type - 资源类型
   * @param {number} amount - 数量
   * @param {string} id - 资源ID（可选）
   */
  canAfford(type, amount, id = null) {
    return this.get(type, id) >= amount;
  }

  /**
   * 获取所有资源数据（用于存档）
   */
  getAllResources() {
    return JSON.parse(JSON.stringify(this.resources));
  }

  /**
   * 加载资源数据（用于读档）
   */
  loadResources(data) {
    if (data) {
      this.resources = JSON.parse(JSON.stringify(data));
    }
  }

  /**
   * 设置资源（用于初始化或重置）
   * @param {string} type - 资源类型
   * @param {number} value - 数值
   * @param {string} id - 资源ID（可选）
   */
  set(type, value, id = null) {
    if (id) {
      if (!this.resources[type]) this.resources[type] = {};
      this.resources[type][id] = value;
    } else {
      this.resources[type] = value;
    }
  }

  /**
   * 注册资源变化监听器
   */
  onResourceChanged(callback, context = null) {
    this.eventManager.on(GameEvents.RESOURCE_CHANGED, callback, context);
  }

  /**
   * 注册金币变化监听器
   */
  onGoldChanged(callback, context = null) {
    this.eventManager.on(GameEvents.GOLD_CHANGED, callback, context);
  }
}

module.exports = ResourceSystem;
