/**
 * 存档系统
 * 负责游戏数据的本地存储、自动保存、数据校验和迁移
 */
const { EventManager, GameEvents } = require('../core/EventManager');

const SAVE_KEYS = {
  AUTO_SAVE: 'farm_game_auto_save',
  MANUAL_SAVE: 'farm_game_manual_save',
  SETTINGS: 'farm_game_settings'
};

const SAVE_VERSION = '1.0.0';

class SaveSystem {
  constructor() {
    this.eventManager = new EventManager();
    this.lastSaveTime = 0;
    this.autoSaveInterval = 30000; // 30秒自动保存
    this.autoSaveTimer = null;

    this.currentSave = this.getDefaultSaveData();
  }

  /**
   * 获取默认存档数据
   */
  getDefaultSaveData() {
    return {
      version: SAVE_VERSION,
      timestamp: Date.now(),
      player: {
        name: '农民',
        level: 1,
        experience: 0,
        gold: 100,
        createdAt: Date.now(),
        lastLoginAt: Date.now()
      },
      farm: {
        lands: this.getDefaultLands(),
        animals: [],
        buildings: {
          barnLevel: 1
        }
      },
      resources: {
        seeds: {},
        crops: {},
        feeds: {},
        animalProducts: {},
        tools: {}
      },
      shop: {
        purchasedUpgrades: [],
        landPurchases: 0,
        barnPurchases: 0,
        dailyPurchases: {}
      },
      settings: {
        soundEnabled: true,
        musicEnabled: true,
        notificationEnabled: true
      }
    };
  }

  /**
   * 获取默认土地数据
   */
  getDefaultLands() {
    const lands = [];
    for (let i = 0; i < 16; i++) {
      lands.push({
        id: i,
        status: i < 4 ? 'empty' : 'locked', // 前4块初始解锁
        cropId: null,
        plantedAt: null,
        level: 1,
        isUnlocked: i < 4
      });
    }
    return lands;
  }

  /**
   * 保存游戏
   * @param {string} type - 保存类型 'auto' | 'manual'
   */
  save(type = 'auto') {
    try {
      this.currentSave.timestamp = Date.now();
      this.currentSave.player.lastLoginAt = Date.now();

      const saveKey = type === 'auto' ? SAVE_KEYS.AUTO_SAVE : SAVE_KEYS.MANUAL_SAVE;
      wx.setStorageSync(saveKey, this.currentSave);

      this.lastSaveTime = Date.now();
      this.eventManager.emit(GameEvents.GAME_SAVED, { type, timestamp: this.lastSaveTime });
      console.log(`游戏已保存 (${type})`);
      return true;
    } catch (error) {
      console.error('保存游戏失败:', error);
      return false;
    }
  }

  /**
   * 加载游戏
   */
  load() {
    try {
      const saveData = wx.getStorageSync(SAVE_KEYS.AUTO_SAVE);
      if (!saveData) {
        console.log('没有找到存档，使用默认数据');
        this.currentSave = this.getDefaultSaveData();
        return false;
      }

      // 数据校验和迁移
      if (this.validateSave(saveData)) {
        this.currentSave = this.migrateData(saveData);
        this.lastSaveTime = this.currentSave.timestamp;
        this.eventManager.emit(GameEvents.GAME_LOADED, { timestamp: this.lastSaveTime });
        console.log('游戏已加载');
        return true;
      } else {
        console.error('存档数据无效，使用默认数据');
        this.currentSave = this.getDefaultSaveData();
        return false;
      }
    } catch (error) {
      console.error('加载游戏失败:', error);
      this.currentSave = this.getDefaultSaveData();
      return false;
    }
  }

  /**
   * 验证存档数据
   */
  validateSave(data) {
    if (!data) return false;
    if (!data.version) return false;
    if (!data.player) return false;
    if (!data.farm) return false;
    if (!data.farm.lands || !Array.isArray(data.farm.lands)) return false;
    return true;
  }

  /**
   * 迁移旧版本存档数据
   */
  migrateData(oldData) {
    let data = JSON.parse(JSON.stringify(oldData));

    // 版本迁移逻辑
    if (!data.version || data.version < '1.0.0') {
      // 初始化新版字段
      if (!data.resources) {
        data.resources = {
          seeds: {},
          crops: {},
          feeds: {},
          animalProducts: {},
          tools: {}
        };
      }
      if (!data.settings) {
        data.settings = {
          soundEnabled: true,
          musicEnabled: true,
          notificationEnabled: true
        };
      }
      if (!data.shop) {
        data.shop = {
          purchasedUpgrades: [],
          landPurchases: 0,
          barnPurchases: 0,
          dailyPurchases: {}
        };
      }
      if (!data.farm.buildings) {
        data.farm.buildings = { barnLevel: 1 };
      }
      // 确保动物数组存在
      if (!data.farm.animals) {
        data.farm.animals = [];
      }
      // 确保土地数组存在
      if (data.farm.lands && Array.isArray(data.farm.lands)) {
        data.farm.lands.forEach((land, i) => {
          if (land.isUnlocked === undefined) {
            land.isUnlocked = i < 4;
          }
        });
      } else {
        data.farm.lands = [];
      }
    }

    data.version = SAVE_VERSION;
    return data;
  }

  /**
   * 获取存档信息
   */
  getSaveInfo() {
    try {
      const saveData = wx.getStorageSync(SAVE_KEYS.AUTO_SAVE);
      if (!saveData) {
        return { exists: false };
      }
      return {
        exists: true,
        timestamp: saveData.timestamp,
        version: saveData.version,
        level: saveData.player ? saveData.player.level : 1,
        gold: saveData.player ? saveData.player.gold : 0
      };
    } catch (error) {
      return { exists: false };
    }
  }

  /**
   * 删除存档
   */
  deleteSave() {
    try {
      wx.removeStorageSync(SAVE_KEYS.AUTO_SAVE);
      wx.removeStorageSync(SAVE_KEYS.MANUAL_SAVE);
      this.currentSave = this.getDefaultSaveData();
      this.lastSaveTime = 0;
      console.log('存档已删除');
      return true;
    } catch (error) {
      console.error('删除存档失败:', error);
      return false;
    }
  }

  /**
   * 获取当前存档数据
   */
  getCurrentSave() {
    return this.currentSave;
  }

  /**
   * 更新存档数据
   * @param {string} path - 数据路径，如 'player.gold'
   * @param {*} value - 新值
   */
  updateSave(path, value) {
    const paths = path.split('.');
    let current = this.currentSave;

    for (let i = 0; i < paths.length - 1; i++) {
      if (current[paths[i]] === undefined) {
        current[paths[i]] = {};
      }
      current = current[paths[i]];
    }

    current[paths[paths.length - 1]] = value;
  }

  /**
   * 获取最后保存时间
   */
  getLastSaveTime() {
    return this.lastSaveTime;
  }

  /**
   * 启动自动保存
   */
  startAutoSave() {
    if (this.autoSaveTimer) return;

    this.autoSaveTimer = setInterval(() => {
      this.save('auto');
    }, this.autoSaveInterval);

    console.log('自动保存已启动');
  }

  /**
   * 停止自动保存
   */
  stopAutoSave() {
    if (this.autoSaveTimer) {
      clearInterval(this.autoSaveTimer);
      this.autoSaveTimer = null;
      console.log('自动保存已停止');
    }
  }

  /**
   * 注册存档加载监听器
   */
  onGameLoaded(callback, context = null) {
    this.eventManager.on(GameEvents.GAME_LOADED, callback, context);
  }

  /**
   * 注册存档保存监听器
   */
  onGameSaved(callback, context = null) {
    this.eventManager.on(GameEvents.GAME_SAVED, callback, context);
  }
}

module.exports = SaveSystem;
