/**
 * 作物系统
 * 负责管理作物配置、生长周期、收获计算
 */
const cropsData = require('../data/crops');

class CropSystem {
  constructor() {
    this.crops = new Map();
    this.loadCrops();
  }

  /**
   * 加载作物配置
   */
  loadCrops() {
    cropsData.crops.forEach(crop => {
      this.crops.set(crop.id, crop);
    });
    console.log(`已加载 ${this.crops.size} 种作物`);
  }

  /**
   * 获取作物配置
   */
  getCropConfig(cropId) {
    return this.crops.get(cropId);
  }

  /**
   * 获取所有作物配置
   */
  getAllCrops() {
    return Array.from(this.crops.values());
  }

  /**
   * 获取玩家可种的作物
   * @param {number} playerLevel - 玩家等级
   * @param {number} landLevel - 土地等级
   */
  getAvailableCrops(playerLevel, landLevel) {
    return this.getAllCrops().filter(crop => {
      return crop.requiredLandLevel <= landLevel;
    });
  }

  /**
   * 计算实际生长时间（考虑等级加成）
   * @param {string} cropId - 作物ID
   * @param {number} growthSpeedBonus - 生长速度加成百分比
   */
  calculateGrowthTime(cropId, growthSpeedBonus = 0) {
    const config = this.getCropConfig(cropId);
    if (!config) return 0;

    const bonus = 1 - (growthSpeedBonus / 100);
    return config.growthTime * bonus;
  }

  /**
   * 计算实际产量（考虑加成）
   * @param {string} cropId - 作物ID
   * @param {number} yieldBonus - 产量加成百分比
   */
  calculateYield(cropId, yieldBonus = 0) {
    const config = this.getCropConfig(cropId);
    if (!config) return 0;

    return Math.floor(config.harvestYield * (1 + yieldBonus / 100));
  }

  /**
   * 计算作物售价
   * @param {string} cropId - 作物ID
   */
  calculateSellPrice(cropId) {
    const config = this.getCropConfig(cropId);
    if (!config) return 0;
    return config.sellPrice;
  }

  /**
   * 获取作物名称
   * @param {string} cropId - 作物ID
   */
  getCropName(cropId) {
    const config = this.getCropConfig(cropId);
    return config ? config.name : '';
  }
}

module.exports = CropSystem;
