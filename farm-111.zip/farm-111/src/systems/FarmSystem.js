/**
 * 农场/土地系统
 * 负责土地管理、种植、收获等
 */
const { EventManager, GameEvents } = require('../core/EventManager');
const TimeManager = require('../core/TimeManager');

class FarmSystem {
  constructor(cropSystem, saveSystem) {
    this.cropSystem = cropSystem;
    this.saveSystem = saveSystem;
    this.eventManager = new EventManager();
    this.timeManager = new TimeManager();

    // 从存档加载土地数据
    this.lands = [];
    this.loadFromSave();
  }

  /**
   * 从存档加载土地数据
   */
  loadFromSave() {
    const saveData = this.saveSystem.getCurrentSave();
    if (saveData && saveData.farm && saveData.farm.lands) {
      this.lands = JSON.parse(JSON.stringify(saveData.farm.lands));
    } else {
      this.initDefaultLands();
    }
  }

  /**
   * 初始化默认土地
   */
  initDefaultLands() {
    this.lands = [];
    for (let i = 0; i < 16; i++) {
      this.lands.push({
        id: i,
        status: i < 4 ? 'empty' : 'locked',
        cropId: null,
        plantedAt: null,
        level: 1,
        isUnlocked: i < 4
      });
    }
  }

  /**
   * 保存土地数据到存档
   */
  saveToSaveSystem() {
    this.saveSystem.updateSave('farm.lands', JSON.parse(JSON.stringify(this.lands)));
  }

  /**
   * 更新土地状态
   * @param {number} landIndex - 土地索引
   */
  updateLandStatus(landIndex) {
    if (landIndex < 0 || landIndex >= this.lands.length) return;

    const land = this.lands[landIndex];
    if (land.status === 'locked' || land.status === 'empty') return;
    if (!land.cropId || !land.plantedAt) return;

    const cropConfig = this.cropSystem.getCropConfig(land.cropId);
    if (!cropConfig) return;

    const currentTime = Date.now();
    const readyTime = land.plantedAt + cropConfig.growthTime * 1000;

    if (currentTime >= readyTime) {
      if (land.status !== 'ready') {
        land.status = 'ready';
        this.eventManager.emit(GameEvents.LAND_STATUS_CHANGED, { landIndex, status: 'ready' });
        this.eventManager.emit(GameEvents.CROP_READY, { landIndex, cropId: land.cropId });
      }
    }
  }

  /**
   * 更新所有土地的生长状态
   * @param {number} deltaTime - 距离上一帧的时间（秒）
   */
  updateGrowth(deltaTime) {
    const currentTime = Date.now();

    this.lands.forEach((land, index) => {
      if (land.status === 'growing' || land.status === 'planted') {
        if (land.cropId && land.plantedAt) {
          const cropConfig = this.cropSystem.getCropConfig(land.cropId);
          if (cropConfig) {
            const readyTime = land.plantedAt + cropConfig.growthTime * 1000;
            if (currentTime >= readyTime) {
              land.status = 'ready';
              this.eventManager.emit(GameEvents.CROP_READY, { landIndex: index, cropId: land.cropId });
            }
          }
        }
      }
    });
  }

  /**
   * 解锁土地
   * @param {number} landIndex - 土地索引
   * @param {number} cost - 解锁费用
   * @returns {boolean} 是否成功
   */
  unlockLand(landIndex, cost) {
    if (landIndex < 0 || landIndex >= this.lands.length) return false;

    const land = this.lands[landIndex];
    if (land.isUnlocked) return false;

    // 更新存档中的购买计数
    const shop = this.saveSystem.getCurrentSave().shop || { landPurchases: 0 };
    this.saveSystem.updateSave('shop.landPurchases', (shop.landPurchases || 0) + 1);

    land.isUnlocked = true;
    land.status = 'empty';
    this.saveToSaveSystem();

    this.eventManager.emit(GameEvents.LAND_UNLOCKED, { landIndex });
    return true;
  }

  /**
   * 升级土地
   * @param {number} landIndex - 土地索引
   * @returns {boolean} 是否成功
   */
  upgradeLand(landIndex) {
    if (landIndex < 0 || landIndex >= this.lands.length) return false;

    const land = this.lands[landIndex];
    if (!land.isUnlocked) return false;
    if (land.level >= 5) return false; // 最大等级

    land.level++;
    this.saveToSaveSystem();
    return true;
  }

  /**
   * 种植作物
   * @param {number} landIndex - 土地索引
   * @param {string} cropId - 作物ID
   * @returns {boolean} 是否成功
   */
  plantCrop(landIndex, cropId) {
    if (landIndex < 0 || landIndex >= this.lands.length) return false;

    const land = this.lands[landIndex];
    if (!land.isUnlocked) return false;
    if (land.status !== 'empty') return false;

    const cropConfig = this.cropSystem.getCropConfig(cropId);
    if (!cropConfig) return false;

    land.cropId = cropId;
    land.plantedAt = Date.now();
    land.status = 'growing';

    this.saveToSaveSystem();
    this.eventManager.emit(GameEvents.LAND_PLANTED, { landIndex, cropId });

    return true;
  }

  /**
   * 收获作物
   * @param {number} landIndex - 土地索引
   * @param {number} yieldBonus - 产量加成百分比
   * @returns {object|null} 收获结果
   */
  harvest(landIndex, yieldBonus = 0) {
    if (landIndex < 0 || landIndex >= this.lands.length) return null;

    const land = this.lands[landIndex];
    if (land.status !== 'ready') return null;
    if (!land.cropId) return null;

    const cropConfig = this.cropSystem.getCropConfig(land.cropId);
    if (!cropConfig) return null;

    // 计算实际产量
    const yield_count = Math.floor(cropConfig.harvestYield * (1 + yieldBonus / 100));

    // 重置土地状态
    const cropId = land.cropId;
    const experience = cropConfig.experience;

    land.cropId = null;
    land.plantedAt = null;
    land.status = 'empty';

    this.saveToSaveSystem();
    this.eventManager.emit(GameEvents.LAND_HARVESTED, {
      landIndex,
      cropId,
      yield: yield_count,
      experience
    });

    return {
      cropId,
      yield: yield_count,
      experience,
      sellPrice: cropConfig.sellPrice * yield_count
    };
  }

  /**
   * 获取土地信息
   */
  getLand(landIndex) {
    if (landIndex < 0 || landIndex >= this.lands.length) return null;
    return this.lands[landIndex];
  }

  /**
   * 获取所有土地
   */
  getAllLands() {
    return this.lands;
  }

  /**
   * 获取可解锁的土地数量
   */
  getUnlockableLandCount() {
    return this.lands.filter(land => !land.isUnlocked).length;
  }

  /**
   * 计算解锁土地的价格
   */
  calculateLandUnlockCost() {
    const shop = this.saveSystem.getCurrentSave().shop || { landPurchases: 0 };
    const purchases = shop.landPurchases || 0;
    return Math.floor(100 * Math.pow(1.5, purchases));
  }

  /**
   * 应用离线收益
   */
  applyOfflineEarnings(earnings) {
    // 将离线收获的作物添加到库存
    if (earnings.crops) {
      Object.entries(earnings.crops).forEach(([cropId, count]) => {
        // 这里会通过事件通知 ResourceSystem 添加资源
        this.eventManager.emit('offlineCropCollected', { cropId, count });
      });
    }
  }

  /**
   * 注册土地状态变化监听器
   */
  onLandStatusChanged(callback, context = null) {
    this.eventManager.on(GameEvents.LAND_STATUS_CHANGED, callback, context);
  }

  /**
   * 注册作物成熟监听器
   */
  onCropReady(callback, context = null) {
    this.eventManager.on(GameEvents.CROP_READY, callback, context);
  }

  /**
   * 注册土地种植监听器
   */
  onLandPlanted(callback, context = null) {
    this.eventManager.on(GameEvents.LAND_PLANTED, callback, context);
  }

  /**
   * 注册土地收获监听器
   */
  onLandHarvested(callback, context = null) {
    this.eventManager.on(GameEvents.LAND_HARVESTED, callback, context);
  }
}

module.exports = FarmSystem;
