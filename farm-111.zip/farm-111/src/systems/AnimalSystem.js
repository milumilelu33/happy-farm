/**
 * 动物系统
 * 负责动物养殖、产品产出等
 */
const { EventManager, GameEvents } = require('../core/EventManager');
const animalsData = require('../data/animals');

class AnimalSystem {
  constructor(saveSystem) {
    this.saveSystem = saveSystem;
    this.eventManager = new EventManager();

    // 动物配置
    this.animals = new Map();
    this.loadAnimalConfigs();

    // 玩家拥有的动物实例
    this.animalInstances = [];
    this.loadFromSave();

    // 谷仓容量
    this.barnCapacity = 4;
  }

  /**
   * 加载动物配置
   */
  loadAnimalConfigs() {
    animalsData.animals.forEach(animal => {
      this.animals.set(animal.id, animal);
    });
    console.log(`已加载 ${this.animals.size} 种动物`);
  }

  /**
   * 从存档加载动物数据
   */
  loadFromSave() {
    const saveData = this.saveSystem.getCurrentSave();
    if (saveData && saveData.farm && saveData.farm.animals) {
      this.animalInstances = JSON.parse(JSON.stringify(saveData.farm.animals));
    }
    if (saveData && saveData.farm && saveData.farm.buildings) {
      this.barnCapacity = (saveData.farm.buildings.barnLevel || 1) * 2 + 2;
    }
  }

  /**
   * 保存动物数据到存档
   */
  saveToSaveSystem() {
    this.saveSystem.updateSave('farm.animals', JSON.parse(JSON.stringify(this.animalInstances)));
  }

  /**
   * 获取动物配置
   */
  getAnimalConfig(animalId) {
    return this.animals.get(animalId);
  }

  /**
   * 获取所有动物配置
   */
  getAllAnimalConfigs() {
    return Array.from(this.animals.values());
  }

  /**
   * 获取玩家可购买的动物
   * @param {number} playerLevel - 玩家等级
   */
  getAvailableAnimals(playerLevel) {
    return this.getAllAnimalConfigs().filter(animal => {
      return animal.requiredBarnLevel <= this.getBarnLevel();
    });
  }

  /**
   * 获取谷仓等级
   */
  getBarnLevel() {
    const saveData = this.saveSystem.getCurrentSave();
    return (saveData && saveData.farm && saveData.farm.buildings && saveData.farm.buildings.barnLevel) || 1;
  }

  /**
   * 获取谷仓容量
   */
  getBarnCapacity() {
    return this.barnCapacity;
  }

  /**
   * 购买动物
   * @param {string} animalId - 动物配置ID
   * @returns {object|null} 购买的动物实例
   */
  buyAnimal(animalId) {
    const config = this.getAnimalConfig(animalId);
    if (!config) return null;

    if (this.animalInstances.length >= this.barnCapacity) {
      console.log('谷仓已满');
      return null;
    }

    const animal = {
      instanceId: `animal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      configId: animalId,
      status: 'baby',
      fedAt: Date.now(),
      lastProductAt: null,
      productReady: false,
      boughtAt: Date.now()
    };

    this.animalInstances.push(animal);
    this.saveToSaveSystem();

    this.eventManager.emit(GameEvents.ANIMAL_BOUGHT, { animal });
    return animal;
  }

  /**
   * 喂养动物
   * @param {string} instanceId - 动物实例ID
   * @returns {boolean} 是否成功
   */
  feedAnimal(instanceId) {
    const animal = this.animalInstances.find(a => a.instanceId === instanceId);
    if (!animal) return false;

    const config = this.getAnimalConfig(animal.configId);
    if (!config) return false;

    animal.fedAt = Date.now();

    // 如果是成长期动物，变成成年
    if (animal.status === 'growing') {
      const currentTime = Date.now();
      const growthTimeMs = config.growthTime * 1000;
      if (currentTime - animal.boughtAt >= growthTimeMs) {
        animal.status = 'adult';
      }
    }

    this.saveToSaveSystem();
    this.eventManager.emit(GameEvents.ANIMAL_FED, { instanceId });
    return true;
  }

  /**
   * 更新动物状态
   * @param {number} deltaTime - 距离上一帧的时间（秒）
   */
  update(deltaTime) {
    const currentTime = Date.now();

    this.animalInstances.forEach(animal => {
      const config = this.getAnimalConfig(animal.configId);
      if (!config) return;

      // 检查是否成年
      if (animal.status === 'baby' || animal.status === 'growing') {
        const growthTimeMs = config.growthTime * 1000;
        if (currentTime - animal.boughtAt >= growthTimeMs) {
          animal.status = 'adult';
        }
      }

      // 成年后开始检查产出
      if (animal.status === 'adult') {
        // 检查是否需要喂食
        const feedIntervalMs = config.feedInterval * 1000;
        const lastFeedAt = animal.lastProductAt || animal.fedAt;

        // 如果太久没喂食，停止产出
        if (currentTime - lastFeedAt > feedIntervalMs * 2) {
          animal.productReady = false;
        } else {
          // 检查是否可以产出
          const productIntervalMs = config.productInterval * 1000;
          const lastProductTime = animal.lastProductAt || animal.fedAt;

          if (currentTime - lastProductTime >= productIntervalMs) {
            animal.productReady = true;
            this.eventManager.emit(GameEvents.ANIMAL_PRODUCT_READY, {
              instanceId: animal.instanceId,
              productId: config.productId
            });
          }
        }
      }
    });
  }

  /**
   * 收集动物产品
   * @param {string} instanceId - 动物实例ID
   * @returns {object|null} 收集结果
   */
  collectProduct(instanceId) {
    const animal = this.animalInstances.find(a => a.instanceId === instanceId);
    if (!animal) return null;

    if (!animal.productReady) return null;

    const config = this.getAnimalConfig(animal.configId);
    if (!config) return null;

    animal.productReady = false;
    animal.lastProductAt = Date.now();

    this.saveToSaveSystem();

    const result = {
      productId: config.productId,
      productName: config.productName,
      count: config.productYield,
      sellPrice: config.sellPrice
    };

    this.eventManager.emit(GameEvents.ANIMAL_PRODUCT_COLLECTED, {
      instanceId,
      ...result
    });

    return result;
  }

  /**
   * 获取所有动物
   */
  getAllAnimals() {
    return this.animalInstances;
  }

  /**
   * 获取单个动物
   */
  getAnimal(instanceId) {
    return this.animalInstances.find(a => a.instanceId === instanceId);
  }

  /**
   * 获取可收获产品的动物
   */
  getAnimalsWithProduct() {
    return this.animalInstances.filter(a => a.productReady);
  }

  /**
   * 扩建谷仓
   */
  expandBarn() {
    const shop = this.saveSystem.getCurrentSave().shop || { barnPurchases: 0 };
    this.saveSystem.updateSave('shop.barnPurchases', (shop.barnPurchases || 0) + 1);

    const currentBarnLevel = this.getBarnLevel();
    this.saveSystem.updateSave('farm.buildings.barnLevel', currentBarnLevel + 1);
    this.barnCapacity = (currentBarnLevel + 1) * 2 + 2;
  }

  /**
   * 注册动物产品可收集监听器
   */
  onAnimalProductReady(callback, context = null) {
    this.eventManager.on(GameEvents.ANIMAL_PRODUCT_READY, callback, context);
  }

  /**
   * 注册动物产品收集监听器
   */
  onAnimalProductCollected(callback, context = null) {
    this.eventManager.on(GameEvents.ANIMAL_PRODUCT_COLLECTED, callback, context);
  }
}

module.exports = AnimalSystem;
