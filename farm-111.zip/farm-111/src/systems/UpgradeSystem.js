/**
 * 升级系统
 * 负责玩家等级、经验值、升级加成
 */
const { EventManager, GameEvents } = require('../core/EventManager');
const levelsData = require('../data/levels');

class UpgradeSystem {
  constructor(saveSystem) {
    this.saveSystem = saveSystem;
    this.eventManager = new EventManager();

    // 玩家数据
    this.playerLevel = 1;
    this.playerExperience = 0;

    // 升级加成
    this.bonuses = {
      growthSpeed: 0,    // 生长速度加成 (%)
      yield: 0,           // 产量加成 (%)
      landCapacity: 4,    // 土地容量
      barnCapacity: 4     // 谷仓容量
    };

    // 已购买的升级
    this.purchasedUpgrades = new Set();

    this.loadFromSave();
  }

  /**
   * 从存档加载数据
   */
  loadFromSave() {
    const saveData = this.saveSystem.getCurrentSave();
    if (saveData && saveData.player) {
      this.playerLevel = saveData.player.level || 1;
      this.playerExperience = saveData.player.experience || 0;
    }
    if (saveData && saveData.shop && saveData.shop.purchasedUpgrades) {
      this.purchasedUpgrades = new Set(saveData.shop.purchasedUpgrades);
    }
    this.calculateBonuses();
  }

  /**
   * 计算当前加成
   */
  calculateBonuses() {
    const levelConfig = this.getLevelConfig(this.playerLevel);
    if (levelConfig) {
      this.bonuses.growthSpeed = levelConfig.growthSpeedBonus || 0;
      this.bonuses.yield = levelConfig.yieldBonus || 0;
      this.bonuses.landCapacity = levelConfig.unlockLandCount || 4;
      this.bonuses.barnCapacity = levelConfig.unlockBarnCount || 2;
    }
  }

  /**
   * 获取等级配置
   */
  getLevelConfig(level) {
    return levelsData.levels.find(l => l.level === level);
  }

  /**
   * 获取玩家等级
   */
  getPlayerLevel() {
    return this.playerLevel;
  }

  /**
   * 获取玩家经验
   */
  getPlayerExperience() {
    return this.playerExperience;
  }

  /**
   * 获取当前等级配置
   */
  getCurrentLevelConfig() {
    return this.getLevelConfig(this.playerLevel);
  }

  /**
   * 获取下一级配置
   */
  getNextLevelConfig() {
    return this.getLevelConfig(this.playerLevel + 1);
  }

  /**
   * 获取升级所需经验
   */
  getExperienceToNextLevel() {
    const nextConfig = this.getNextLevelConfig();
    if (!nextConfig) return null;
    return nextConfig.experienceRequired - this.playerExperience;
  }

  /**
   * 获取当前等级加成
   */
  getBonuses() {
    return { ...this.bonuses };
  }

  /**
   * 添加经验值
   * @param {number} exp - 经验值
   * @returns {boolean} 是否升级
   */
  addExperience(exp) {
    this.playerExperience += exp;
    let leveledUp = false;

    // 检查是否可以升级
    let nextConfig = this.getNextLevelConfig();
    while (nextConfig && this.playerExperience >= nextConfig.experienceRequired) {
      this.playerLevel++;
      leveledUp = true;
      this.calculateBonuses();

      // 检查是否解锁新内容
      if (nextConfig.unlockCropIds && nextConfig.unlockCropIds.length > 0) {
        this.eventManager.emit('unlockCrops', { crops: nextConfig.unlockCropIds });
      }
      if (nextConfig.unlockAnimalIds && nextConfig.unlockAnimalIds.length > 0) {
        this.eventManager.emit('unlockAnimals', { animals: nextConfig.unlockAnimalIds });
      }

      this.eventManager.emit(GameEvents.LEVEL_UP, {
        level: this.playerLevel,
        bonuses: this.bonuses
      });

      nextConfig = this.getNextLevelConfig();
    }

    // 保存到存档
    this.saveToSaveSystem();
    return leveledUp;
  }

  /**
   * 保存到存档
   */
  saveToSaveSystem() {
    this.saveSystem.updateSave('player.level', this.playerLevel);
    this.saveSystem.updateSave('player.experience', this.playerExperience);
    this.saveSystem.updateSave('shop.purchasedUpgrades', Array.from(this.purchasedUpgrades));
  }

  /**
   * 获取解锁的作物
   */
  getUnlockedCrops() {
    const config = this.getCurrentLevelConfig();
    return config ? config.unlockCropIds || [] : [];
  }

  /**
   * 获取解锁的动物
   */
  getUnlockedAnimals() {
    const config = this.getCurrentLevelConfig();
    return config ? config.unlockAnimalIds || [] : [];
  }

  /**
   * 注册升级监听器
   */
  onLevelUp(callback, context = null) {
    this.eventManager.on(GameEvents.LEVEL_UP, callback, context);
  }
}

module.exports = UpgradeSystem;
