/**
 * 商店系统
 * 负责商品购买、每日限购等
 */
const { EventManager, GameEvents } = require('../core/EventManager');
const shopData = require('../data/shop');

class ShopSystem {
  constructor(resourceSystem, cropSystem, animalSystem, upgradeSystem) {
    this.resourceSystem = resourceSystem;
    this.cropSystem = cropSystem;
    this.animalSystem = animalSystem;
    this.upgradeSystem = upgradeSystem;
    this.eventManager = new EventManager();

    // 加载商店配置
    this.items = [];
    this.loadShopItems();

    // 今日购买记录
    this.dailyPurchases = {};
    this.loadDailyPurchases();
  }

  /**
   * 加载商店配置
   */
  loadShopItems() {
    this.items = shopData.shopItems;
    console.log(`已加载 ${this.items.length} 个商店商品`);
  }

  /**
   * 加载每日购买记录
   */
  loadDailyPurchases() {
    const saveData = this.saveSystem ? this.saveSystem.getCurrentSave() : null;
    if (saveData && saveData.shop && saveData.shop.dailyPurchases) {
      const savedDate = saveData.shop.dailyPurchases.date;
      const today = new Date().toDateString();

      // 检查是否是同一天
      if (savedDate === today) {
        this.dailyPurchases = saveData.shop.dailyPurchases;
      } else {
        // 新的一天，重置限购
        this.dailyPurchases = { date: today };
        this.saveDailyPurchases();
      }
    } else {
      this.dailyPurchases = { date: new Date().toDateString() };
    }
  }

  /**
   * 保存每日购买记录
   */
  saveDailyPurchases() {
    if (this.saveSystem) {
      this.saveSystem.updateSave('shop.dailyPurchases', this.dailyPurchases);
    }
  }

  /**
   * 设置存档系统引用
   */
  setSaveSystem(saveSystem) {
    this.saveSystem = saveSystem;
    this.loadDailyPurchases();
  }

  /**
   * 获取商品列表
   * @param {string} category - 商品分类
   */
  getItemsByCategory(category) {
    return this.items.filter(item => item.category === category);
  }

  /**
   * 获取所有商品
   */
  getAllItems() {
    return this.items;
  }

  /**
   * 获取商品配置
   */
  getItemConfig(itemId) {
    return this.items.find(item => item.id === itemId);
  }

  /**
   * 计算商品价格
   * @param {object} item - 商品配置
   * @param {number} purchasedCount - 已购买次数
   */
  calculatePrice(item, purchasedCount = 0) {
    if (item.price) {
      return item.price;
    }
    if (item.basePrice && item.priceGrowth) {
      return Math.floor(item.basePrice * Math.pow(item.priceGrowth, purchasedCount));
    }
    return item.basePrice || 0;
  }

  /**
   * 检查是否可以购买
   * @param {string} itemId - 商品ID
   * @param {number} quantity - 购买数量
   */
  canPurchase(itemId, quantity = 1) {
    const item = this.getItemConfig(itemId);
    if (!item) {
      return { canBuy: false, reason: '商品不存在' };
    }

    // 检查等级限制
    const playerLevel = this.upgradeSystem ? this.upgradeSystem.getPlayerLevel() : 1;
    if (item.unlockLevel && item.unlockLevel > playerLevel) {
      return { canBuy: false, reason: `需要等级 ${item.unlockLevel}` };
    }

    // 检查每日限购
    if (item.limitPerDay) {
      const purchased = this.dailyPurchases[itemId] || 0;
      if (purchased + quantity > item.limitPerDay) {
        return { canBuy: false, reason: '今日已达购买上限' };
      }
    }

    // 检查最大购买次数
    if (item.maxPurchases) {
      const totalPurchased = this.dailyPurchases[`${itemId}_total`] || 0;
      if (totalPurchased >= item.maxPurchases) {
        return { canBuy: false, reason: '已达最大购买次数' };
      }
    }

    // 检查金币
    const price = this.calculatePrice(item, this.dailyPurchases[`${itemId}_count`] || 0);
    if (!this.resourceSystem.canAfford('gold', price * quantity)) {
      return { canBuy: false, reason: '金币不足' };
    }

    // 特殊检查：土地
    if (itemId === 'land_expand') {
      const saveData = this.saveSystem ? this.saveSystem.getCurrentSave() : null;
      const landPurchases = (saveData && saveData.shop && saveData.shop.landPurchases) || 0;
      if (landPurchases >= 12) {
        return { canBuy: false, reason: '已解锁所有土地' };
      }
    }

    // 特殊检查：谷仓
    if (itemId === 'barn_expand') {
      const saveData = this.saveSystem ? this.saveSystem.getCurrentSave() : null;
      const barnPurchases = (saveData && saveData.shop && saveData.shop.barnPurchases) || 0;
      if (barnPurchases >= 6) {
        return { canBuy: false, reason: '谷仓已满级' };
      }
    }

    // 特殊检查：谷仓容量
    if (item.category === 'animals') {
      if (this.animalSystem && this.animalSystem.getAllAnimals().length >= this.animalSystem.getBarnCapacity()) {
        return { canBuy: false, reason: '谷仓容量已满' };
      }
    }

    return { canBuy: true };
  }

  /**
   * 购买商品
   * @param {string} itemId - 商品ID
   * @param {number} quantity - 购买数量
   */
  purchase(itemId, quantity = 1) {
    const check = this.canPurchase(itemId, quantity);
    if (!check.canBuy) {
      return { success: false, reason: check.reason };
    }

    const item = this.getItemConfig(itemId);
    const purchasedCount = this.dailyPurchases[`${itemId}_count`] || 0;
    const price = this.calculatePrice(item, purchasedCount);

    // 扣除金币
    if (!this.resourceSystem.consume('gold', price * quantity)) {
      return { success: false, reason: '金币不足' };
    }

    // 更新购买记录
    this.dailyPurchases[itemId] = (this.dailyPurchases[itemId] || 0) + quantity;
    this.dailyPurchases[`${itemId}_count`] = (this.dailyPurchases[`${itemId}_count`] || 0) + quantity;
    this.dailyPurchases[`${itemId}_total`] = (this.dailyPurchases[`${itemId}_total`] || 0) + quantity;
    this.saveDailyPurchases();

    // 处理购买结果
    let result = { success: true, item, quantity, price };

    switch (item.category) {
      case 'seeds':
        // 添加种子到背包
        const seedId = item.id.replace('_seeds', '');
        this.resourceSystem.add('seeds', quantity, seedId);
        result.message = `获得 ${item.name} x${quantity}`;
        break;

      case 'animals':
        // 购买动物
        const animalId = item.id;
        const animal = this.animalSystem.buyAnimal(animalId);
        if (animal) {
          result.message = `获得 ${item.name}`;
        } else {
          // 退款
          this.resourceSystem.add('gold', price * quantity);
          return { success: false, reason: '谷仓容量已满' };
        }
        break;

      case 'tools':
        this.resourceSystem.add('tools', quantity, item.id);
        result.message = `获得 ${item.name} x${quantity}`;
        break;

      case 'buildings':
        if (itemId === 'land_expand') {
          result.message = '土地已解锁';
        } else if (itemId === 'barn_expand') {
          this.animalSystem.expandBarn();
          result.message = '谷仓已扩建';
        }
        break;
    }

    this.eventManager.emit(GameEvents.ITEM_PURCHASED, result);
    return result;
  }

  /**
   * 获取商品当前价格
   */
  getCurrentPrice(itemId) {
    const item = this.getItemConfig(itemId);
    if (!item) return 0;
    const purchasedCount = this.dailyPurchases[`${itemId}_count`] || 0;
    return this.calculatePrice(item, purchasedCount);
  }

  /**
   * 获取商品今日已购数量
   */
  getTodayPurchased(itemId) {
    return this.dailyPurchases[itemId] || 0;
  }

  /**
   * 注册购买监听器
   */
  onItemPurchased(callback, context = null) {
    this.eventManager.on(GameEvents.ITEM_PURCHASED, callback, context);
  }
}

module.exports = ShopSystem;
