/**
 * 事件总线
 * 负责游戏内各系统之间的通信
 */
class EventManager {
  constructor() {
    this.listeners = new Map();
  }

  /**
   * 注册事件监听器
   * @param {string} event - 事件名称
   * @param {Function} callback - 回调函数
   * @param {Object} context - 上下文
   */
  on(event, callback, context = null) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event).push({ callback, context });
  }

  /**
   * 注册一次性事件监听器
   * @param {string} event - 事件名称
   * @param {Function} callback - 回调函数
   * @param {Object} context - 上下文
   */
  once(event, callback, context = null) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event).push({ callback, context, once: true });
  }

  /**
   * 移除事件监听器
   * @param {string} event - 事件名称
   * @param {Function} callback - 回调函数
   */
  off(event, callback) {
    if (!this.listeners.has(event)) return;

    const listeners = this.listeners.get(event);
    const filtered = listeners.filter(listener => listener.callback !== callback);
    this.listeners.set(event, filtered);
  }

  /**
   * 触发事件
   * @param {string} event - 事件名称
   * @param {*} data - 事件数据
   */
  emit(event, data = null) {
    if (!this.listeners.has(event)) return;

    const listeners = this.listeners.get(event);
    const toRemove = [];

    listeners.forEach((listener, index) => {
      try {
        if (listener.context) {
          listener.callback.call(listener.context, data);
        } else {
          listener.callback(data);
        }

        if (listener.once) {
          toRemove.push(index);
        }
      } catch (error) {
        console.error(`事件 ${event} 执行出错:`, error);
      }
    });

    // 移除一次性监听器
    for (let i = toRemove.length - 1; i >= 0; i--) {
      listeners.splice(toRemove[i], 1);
    }
  }

  /**
   * 清空所有监听器
   */
  clear() {
    this.listeners.clear();
  }

  /**
   * 移除指定事件的所有监听器
   * @param {string} event - 事件名称
   */
  clearEvent(event) {
    this.listeners.delete(event);
  }
}

// 游戏事件名称常量
const GameEvents = {
  // 资源相关
  RESOURCE_CHANGED: 'resourceChanged',
  GOLD_CHANGED: 'goldChanged',

  // 土地相关
  LAND_UNLOCKED: 'landUnlocked',
  LAND_PLANTED: 'landPlanted',
  LAND_HARVESTED: 'landHarvested',
  LAND_STATUS_CHANGED: 'landStatusChanged',

  // 作物相关
  CROP_READY: 'cropReady',

  // 动物相关
  ANIMAL_BOUGHT: 'animalBought',
  ANIMAL_FED: 'animalFed',
  ANIMAL_PRODUCT_READY: 'animalProductReady',
  ANIMAL_PRODUCT_COLLECTED: 'animalProductCollected',

  // 商店相关
  ITEM_PURCHASED: 'itemPurchased',
  SHOP_REFRESHED: 'shopRefreshed',

  // 升级相关
  LEVEL_UP: 'levelUp',
  UPGRADE_PURCHASED: 'upgradePurchased',

  // 游戏状态
  GAME_SAVED: 'gameSaved',
  GAME_LOADED: 'gameLoaded',
  OFFLINE_EARNINGS: 'offlineEarnings',

  // UI相关
  UPDATE: 'update',
  TOAST: 'toast'
};

// 导出
module.exports = {
  EventManager,
  GameEvents
};
