/**
 * 时间管理器
 * 负责游戏内计时器管理、格式化时间显示
 */
class TimeManager {
  constructor() {
    this.timers = new Map();
    this.nextTimerId = 0;
  }

  /**
   * 创建一个新的计时器
   * @param {number} duration - 持续时间（秒）
   * @param {Function} callback - 回调函数
   * @param {boolean} repeat - 是否重复
   * @returns {number} 计时器ID
   */
  createTimer(duration, callback, repeat = false) {
    const id = ++this.nextTimerId;
    this.timers.set(id, {
      duration,
      remaining: duration,
      callback,
      repeat,
      isPaused: false
    });
    return id;
  }

  /**
   * 更新计时器
   * @param {number} deltaTime - 距离上一帧的时间（秒）
   */
  update(deltaTime) {
    const timersToRemove = [];

    this.timers.forEach((timer, id) => {
      if (timer.isPaused) return;

      timer.remaining -= deltaTime;

      if (timer.remaining <= 0) {
        timer.callback();

        if (timer.repeat) {
          timer.remaining = timer.duration;
        } else {
          timersToRemove.push(id);
        }
      }
    });

    timersToRemove.forEach(id => this.timers.delete(id));
  }

  /**
   * 暂停计时器
   */
  pauseTimer(id) {
    const timer = this.timers.get(id);
    if (timer) {
      timer.isPaused = true;
    }
  }

  /**
   * 恢复计时器
   */
  resumeTimer(id) {
    const timer = this.timers.get(id);
    if (timer) {
      timer.isPaused = false;
    }
  }

  /**
   * 删除计时器
   */
  removeTimer(id) {
    this.timers.delete(id);
  }

  /**
   * 清空所有计时器
   */
  clear() {
    this.timers.clear();
  }

  /**
   * 格式化时间为 MM:SS 或 HH:MM:SS
   * @param {number} seconds - 秒数
   */
  static formatTime(seconds) {
    if (seconds < 0) seconds = 0;

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (hours > 0) {
      return `${hours}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
    return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }

  /**
   * 格式化时间为中文描述
   * @param {number} seconds - 秒数
   */
  static formatTimeChinese(seconds) {
    if (seconds < 0) seconds = 0;

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    let result = '';
    if (hours > 0) result += `${hours}小时`;
    if (minutes > 0) result += `${minutes}分钟`;
    if (secs > 0 || result === '') result += `${secs}秒`;

    return result;
  }

  /**
   * 计算生长进度百分比
   * @param {number} plantedAt - 种植时间戳
   * @param {number} growthTime - 生长时间（秒）
   * @param {number} currentTime - 当前时间戳
   */
  static calculateProgress(plantedAt, growthTime, currentTime) {
    const elapsed = (currentTime - plantedAt) / 1000;
    const progress = Math.min(100, (elapsed / growthTime) * 100);
    return progress;
  }

  /**
   * 获取剩余时间
   * @param {number} plantedAt - 种植时间戳
   * @param {number} growthTime - 生长时间（秒）
   * @param {number} currentTime - 当前时间戳
   */
  static getRemainingTime(plantedAt, growthTime, currentTime) {
    const readyAt = plantedAt + growthTime * 1000;
    const remaining = (readyAt - currentTime) / 1000;
    return Math.max(0, remaining);
  }
}

module.exports = TimeManager;
