/**
 * 游戏主循环引擎
 * 负责游戏更新、帧同步、离线收益计算
 */
class GameEngine {
  constructor(systems) {
    this.farmSystem = systems.farmSystem;
    this.cropSystem = systems.cropSystem;
    this.animalSystem = systems.animalSystem;
    this.saveSystem = systems.saveSystem;

    this.isRunning = false;
    this.lastTime = 0;
    this.deltaTime = 0;
    this.gameLoop = this.gameLoop.bind(this);

    // 事件监听器
    this.listeners = {};
  }

  /**
   * 启动游戏引擎
   */
  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastTime = Date.now();
    this.gameLoop();
    console.log('游戏引擎已启动');
  }

  /**
   * 停止游戏引擎
   */
  stop() {
    this.isRunning = false;
    console.log('游戏引擎已停止');
  }

  /**
   * 游戏主循环
   */
  gameLoop() {
    if (!this.isRunning) return;

    const currentTime = Date.now();
    this.deltaTime = (currentTime - this.lastTime) / 1000; // 转换为秒
    this.lastTime = currentTime;

    // 更新游戏逻辑
    this.update(this.deltaTime);

    // 继续循环
    setTimeout(() => {
      this.gameLoop();
    }, 16); // 约60fps
  }

  /**
   * 更新游戏状态
   * @param {number} deltaTime - 距离上一帧的时间（秒）
   */
  update(deltaTime) {
    // 更新作物生长
    if (this.farmSystem) {
      this.farmSystem.updateGrowth(deltaTime);
    }

    // 更新动物状态
    if (this.animalSystem) {
      this.animalSystem.update(deltaTime);
    }

    // 通知UI更新
    this.emit('update', {
      deltaTime,
      timestamp: Date.now()
    });
  }

  /**
   * 计算离线收益
   */
  calculateOfflineEarnings() {
    const lastSaveTime = this.saveSystem.getLastSaveTime();
    if (!lastSaveTime) return null;

    const currentTime = Date.now();
    const offlineSeconds = (currentTime - lastSaveTime) / 1000;

    // 限制最大离线时间（8小时）
    const maxOfflineSeconds = 8 * 60 * 60;
    const effectiveSeconds = Math.min(offlineSeconds, maxOfflineSeconds);

    if (effectiveSeconds < 60) return null; // 离线少于1分钟不计

    const earnings = {
      offlineSeconds: effectiveSeconds,
      crops: {},
      animalProducts: {},
      totalExperience: 0
    };

    // 计算作物离线生长
    const lands = this.farmSystem.getAllLands();
    for (const land of lands) {
      if (land.status !== 'growing' && land.status !== 'ready') continue;
      if (!land.cropId) continue;

      const cropConfig = this.cropSystem.getCropConfig(land.cropId);
      if (!cropConfig) continue;

      const growthTime = cropConfig.growthTime;
      const readyTime = land.plantedAt + growthTime * 1000;

      if (readyTime <= currentTime) {
        // 计算可以收获的次数
        const cycles = Math.floor(effectiveSeconds / growthTime);
        if (cycles > 0) {
          const yield_count = cropConfig.harvestYield * cycles;
          earnings.crops[cropConfig.id] = (earnings.crops[cropConfig.id] || 0) + yield_count;
          earnings.totalExperience += cropConfig.experience * cycles;
        }
      }
    }

    // 计算动物离线产出
    const animals = this.animalSystem.getAllAnimals();
    for (const animal of animals) {
      if (animal.status !== 'producing') continue;
      const animalConfig = this.animalSystem.getAnimalConfig(animal.configId);
      if (!animalConfig) continue;

      const productInterval = animalConfig.productInterval;
      const cycles = Math.floor(effectiveSeconds / productInterval);
      if (cycles > 0) {
        const productId = animalConfig.productId;
        earnings.animalProducts[productId] = (earnings.animalProducts[productId] || 0) + animalConfig.productYield * cycles;
      }
    }

    // 应用离线收益
    if (Object.keys(earnings.crops).length > 0 || Object.keys(earnings.animalProducts).length > 0) {
      this.farmSystem.applyOfflineEarnings(earnings);
      this.emit('offlineEarnings', earnings);
    }

    return earnings;
  }

  /**
   * 注册事件监听器
   */
  on(event, callback) {
    if (!this.listeners[event]) {
      this.listeners[event] = [];
    }
    this.listeners[event].push(callback);
  }

  /**
   * 移除事件监听器
   */
  off(event, callback) {
    if (!this.listeners[event]) return;
    this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
  }

  /**
   * 触发事件
   */
  emit(event, data) {
    if (!this.listeners[event]) return;
    this.listeners[event].forEach(callback => callback(data));
  }
}

module.exports = GameEngine;
